<?php
session_start();

if ( ! isset($_SESSION["autenticado"]) ){
    echo "
    <script>
    window.location.replace('https://azbistro.000webhostapp.com/Usuario/IncluirUsuario.php);
    </script>
    ";
    
}

?>