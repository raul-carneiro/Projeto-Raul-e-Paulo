<?php
include_once "../servico/Autenticacao.php";
include_once "../servico/Bd.php";

$Titulo=$_GET['titulo'];
$Corpo=$_GET['corpo'];

if (isset($_post['id'])) { //atualiza
    $id = $_GET['id'];
    $sql = "update `texto` set titulo='titulo', corpo='$corpo' where id='$id' ";
}else { //grava um novo
    $sql = "INSERT INTO `usuario` (`id`, `titulo`, `corpo`) VALUES (NULL, 'titulo', 'corpo')";    
}

$bd = new Bd();
$contador = $bd->exec($sql);

echo "<h1>foi armazenado/atualizado $contador registro</h1>";

?>

<a href="consultar.php">Voltar</a>
